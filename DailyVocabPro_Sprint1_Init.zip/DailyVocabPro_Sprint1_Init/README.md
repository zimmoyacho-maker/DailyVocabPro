# DailyVocab Pro

DailyVocab Pro is a personal English vocabulary learning app focused on daily study, SRS review, searchable word data, pronunciation, and AI Tutor-style explanations.

## Current Sprint

**Sprint 1 — Project Foundation**

This repository is being organized as a maintainable Python project so future versions can grow cleanly.

## Planned Features

- Daily new words
- SRS review engine
- Example-first study cards
- Natural Korean example translation
- Search by word, meaning, example, memo, level, and tags
- Study statistics
- Offline pronunciation support
- AI Tutor explanation module
- Quiz mode
- Shadowing mode

## Project Structure

```text
DailyVocabPro/
├── app/
│   ├── core/          # SRS, statistics, search logic
│   ├── database/      # SQLite and Excel import logic
│   ├── services/      # Speech, AI Tutor, external services
│   └── ui/            # Tkinter windows and reusable widgets
├── data/              # words.xlsx and local vocab.db
├── docs/              # roadmap, design notes, changelog
├── tests/             # future tests
├── assets/            # icons/images
├── releases/          # generated release files
├── requirements.txt
└── README.md
```

## Quick Start

```bash
pip install -r requirements.txt
python -m app.main
```

Place `words.xlsx` in the `data/` folder.

## Recommended Excel Format

| word | meaning | example | example_ko | memo | level | tags |
|---|---|---|---|---|---|---|
| abandon | 포기하다 | He abandoned the project. | 그는 그 프로젝트를 포기했다. | project, plan과 자주 사용 | B1 | TOEIC, Business |

## Development Principle

1. Always keep the app runnable.
2. Add features in small, testable increments.
3. Keep the UI calm and study-friendly.
4. Treat word data as the project’s core asset.
5. Prefer maintainability over quick patches.

