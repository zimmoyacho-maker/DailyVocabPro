# Changelog

All notable changes to DailyVocab Pro will be documented here.

## [Unreleased]

### Added
- Initial GitHub-ready project structure.
- README with project overview and quick start.
- ROADMAP for upcoming versions.
- DESIGN document for architecture notes.

## [2.7.0] - Sprint 1

### Added
- Repository foundation.
- Modular folder layout for `app/core`, `app/database`, `app/services`, and `app/ui`.

### Planned
- Migrate previous V2/V3 prototype code into this structure.
