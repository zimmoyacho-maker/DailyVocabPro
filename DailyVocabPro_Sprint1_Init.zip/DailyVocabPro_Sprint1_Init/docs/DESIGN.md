# Design Notes

## Product Goal

DailyVocab Pro is designed to help users build a daily English vocabulary habit through:

1. Example-first learning
2. Natural Korean translation
3. SRS-based review
4. Lightweight AI Tutor explanations
5. Calm, low-friction UI

## Data Model Draft

### words

| column | meaning |
|---|---|
| id | internal ID |
| word | English word |
| meaning | Korean meaning |
| example | English example sentence |
| example_ko | natural Korean translation |
| memo | learning note |
| level | CEFR-style level |
| tags | comma-separated tags |

### progress

| column | meaning |
|---|---|
| word_id | linked word |
| score | memory score |
| interval_days | current review interval |
| next_review | next review date |
| last_review | last review date |
| last_result | know / maybe / dontknow |
| review_count | total reviews |

### study_events

| column | meaning |
|---|---|
| id | event ID |
| day | study date |
| word_id | linked word |
| result | know / maybe / dontknow |
| session_type | new / review / retry |
| created_at | timestamp |

## SRS Draft

- Know: increase interval and score.
- Maybe: short interval, mild score increase.
- Don't know: reset interval to 1 day and lower score.

## UI Principle

Study card order:

```text
word → example → translation → meaning → self-rating
```
