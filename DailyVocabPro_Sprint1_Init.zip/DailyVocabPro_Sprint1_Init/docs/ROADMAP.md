# Roadmap

## V2.7 — Project Foundation

- [x] Public GitHub repository
- [x] Project directory structure
- [x] README, CHANGELOG, ROADMAP, DESIGN docs
- [ ] Move existing app code into modular structure
- [ ] Add basic tests

## V2.8 — Refactor Core App

- [ ] Split database logic
- [ ] Split SRS logic
- [ ] Split UI windows
- [ ] Add logging and safer error handling

## V2.9 — Master Dictionary Workflow

- [ ] Improve `words.xlsx` validation
- [ ] Add example_ko/memo/level/tags quality checks
- [ ] Add import report

## V3.0 — AI Tutor

- [ ] Offline tutor explanation engine
- [ ] Optional API-based tutor backend
- [ ] Tutor panel in study cards

## V3.5 — Quiz Mode

- [ ] Meaning → word quiz
- [ ] Fill-in-the-blank quiz
- [ ] Review missed quiz items

## V4.0 — Memory Coach

- [ ] Study habit analysis
- [ ] Weak word detection
- [ ] Personalized review suggestions

## V5.0 — Shadowing

- [ ] Sentence reading
- [ ] Recording workflow
- [ ] Pronunciation feedback design
