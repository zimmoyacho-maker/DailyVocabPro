"""DailyVocab Pro entry point.

Sprint 1 keeps this minimal. Previous prototype code will be migrated into
modular files during V2.8.
"""

from tkinter import Tk, ttk


class DailyVocabApp(Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("DailyVocab Pro")
        self.geometry("720x480")
        self._build_ui()

    def _build_ui(self) -> None:
        frame = ttk.Frame(self, padding=24)
        frame.pack(fill="both", expand=True)

        ttk.Label(
            frame,
            text="DailyVocab Pro",
            font=("Segoe UI", 22, "bold"),
        ).pack(anchor="w")

        ttk.Label(
            frame,
            text="Sprint 1 foundation is ready. Next step: migrate V2/V3 prototype code into this structure.",
            wraplength=620,
        ).pack(anchor="w", pady=(12, 0))

        ttk.Label(
            frame,
            text="Learn English Smarter.",
            font=("Segoe UI", 12),
        ).pack(anchor="w", pady=(24, 0))


def main() -> None:
    app = DailyVocabApp()
    app.mainloop()


if __name__ == "__main__":
    main()
